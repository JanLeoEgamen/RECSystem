<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Applications & Conversion Metrics')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">
            <!-- Conversion Metrics -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Applicant Conversion Rate</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                        <div class="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Total Applicants</p>
                            <p class="text-2xl font-bold"><?php echo e($totalApplicants); ?></p>
                        </div>
                        <div class="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Converted to Members</p>
                            <p class="text-2xl font-bold"><?php echo e($convertedApplicants); ?></p>
                        </div>
                        <div class="bg-purple-100 dark:bg-purple-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Conversion Rate</p>
                            <p class="text-2xl font-bold"><?php echo e(round($conversionRate, 2)); ?>%</p>
                        </div>
                    </div>
                    <canvas id="conversionChart" height="100"></canvas>
                </div>
            </div>

            <!-- Processing Time -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Application Processing Time</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="bg-yellow-100 dark:bg-yellow-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Average Processing Time (Days)</p>
                            <p class="text-2xl font-bold"><?php echo e(round($processingTimes->avg_days, 1)); ?></p>
                        </div>
                        <div class="bg-orange-100 dark:bg-orange-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Average Processing Time (Hours)</p>
                            <p class="text-2xl font-bold"><?php echo e(round($processingTimes->avg_hours, 1)); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Rejection Analysis -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Rejection Analysis</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                        <div class="bg-red-100 dark:bg-red-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Rejected Applications</p>
                            <p class="text-2xl font-bold"><?php echo e($rejectedApplicants); ?></p>
                        </div>
                        <div class="bg-pink-100 dark:bg-pink-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Rejection Rate</p>
                            <p class="text-2xl font-bold"><?php echo e(round($rejectionRate, 2)); ?>%</p>
                        </div>
                    </div>
                    <!-- Add more detailed rejection reasons if available in your data -->
                </div>
            </div>

            <!-- Pending Applications -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Pending Applications</h3>
                    <div class="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                        <p class="text-2xl font-bold"><?php echo e($pendingApplications); ?></p>
                        <p class="text-sm">Applications awaiting assessment</p>
                    </div>
                    <?php if($pendingApplications > 0): ?>
                        <div class="mt-4">
                            <a href="<?php echo e(route('applicants.index')); ?>" class="inline-flex items-center px-4 py-2 bg-blue-600 border border-transparent rounded-md font-semibold text-xs text-white uppercase tracking-widest hover:bg-blue-700 focus:bg-blue-700 active:bg-blue-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150">
                                Review Pending Applications
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Seasonal Trends -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Seasonal Trends</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <h4 class="font-medium mb-2">Monthly Applications</h4>
                            <canvas id="applicationsTrendChart" height="200"></canvas>
                        </div>
                        <div>
                            <h4 class="font-medium mb-2">Monthly Conversions</h4>
                            <canvas id="conversionsTrendChart" height="200"></canvas>
                        </div>
                    </div>
                    
                    <div class="mt-8 overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead class="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-2 text-left">Year</th>
                                    <th class="px-4 py-2 text-left">Month</th>
                                    <th class="px-4 py-2 text-left">Applications</th>
                                    <th class="px-4 py-2 text-left">Conversions</th>
                                    <th class="px-4 py-2 text-left">Conversion Rate</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <?php $__currentLoopData = $monthlyApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $monthName = DateTime::createFromFormat('!m', $monthData->month)->format('F');
                                            $conversions = $monthlyConversions->get($year)->firstWhere('month', $monthData->month)->count ?? 0;
                                            $conversionRate = $monthData->count > 0 ? ($conversions / $monthData->count) * 100 : 0;
                                        ?>
                                        <tr>
                                            <td class="px-4 py-2"><?php echo e($year); ?></td>
                                            <td class="px-4 py-2"><?php echo e($monthName); ?></td>
                                            <td class="px-4 py-2"><?php echo e($monthData->count); ?></td>
                                            <td class="px-4 py-2"><?php echo e($conversions); ?></td>
                                            <td class="px-4 py-2"><?php echo e(round($conversionRate, 2)); ?>%</td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Conversion Chart
        new Chart(document.getElementById('conversionChart'), {
            type: 'doughnut',
            data: {
                labels: ['Converted', 'Not Converted'],
                datasets: [{
                    data: [<?php echo e($convertedApplicants); ?>, <?php echo e($totalApplicants - $convertedApplicants); ?>],
                    backgroundColor: [
                        'rgba(54, 162, 235, 0.7)',
                        'rgba(255, 99, 132, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { position: 'right' },
                    title: { display: true, text: 'Applicant Conversion' }
                }
            }
        });

        // Applications Trend Chart
        <?php if($monthlyApplications->isNotEmpty()): ?>
        new Chart(document.getElementById('applicationsTrendChart'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode($monthlyApplications->first()->map(function($item) {
                    return DateTime::createFromFormat('!m', $item->month)->format('M');
                }), 512) ?>,
                datasets: [
                    <?php $__currentLoopData = $monthlyApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        label: '<?php echo e($year); ?> Applications',
                        data: <?php echo json_encode($months->pluck('count'), 15, 512) ?>,
                        borderColor: 'rgba(<?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, 1)',
                        backgroundColor: 'rgba(<?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, 0.1)',
                        fill: true,
                        tension: 0.3
                    },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    title: { display: true, text: 'Monthly Applications by Year' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
        <?php endif; ?>

        // Conversions Trend Chart
        <?php if($monthlyConversions->isNotEmpty()): ?>
        new Chart(document.getElementById('conversionsTrendChart'), {
            type: 'line',
            data: {
                labels: <?php echo json_encode($monthlyConversions->first()->map(function($item) {
                    return DateTime::createFromFormat('!m', $item->month)->format('M');
                }), 512) ?>,
                datasets: [
                    <?php $__currentLoopData = $monthlyConversions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    {
                        label: '<?php echo e($year); ?> Conversions',
                        data: <?php echo json_encode($months->pluck('count'), 15, 512) ?>,
                        borderColor: 'rgba(<?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, 1)',
                        backgroundColor: 'rgba(<?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, <?php echo e(rand(50, 200)); ?>, 0.1)',
                        fill: true,
                        tension: 0.3
                    },
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    title: { display: true, text: 'Monthly Conversions by Year' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });
        <?php endif; ?>
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/reports/applications-conversion.blade.php ENDPATH**/ ?>