<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'action' => null,
    'gridColumns' => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4',
    'gap' => 'gap-4'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'action' => null,
    'gridColumns' => 'grid-cols-1 md:grid-cols-2 lg:grid-cols-4',
    'gap' => 'gap-4'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="mb-6 bg-white p-4 rounded-lg shadow">
    <form method="GET" action="<?php echo e($action ?? url()->current()); ?>">
        <div class="grid <?php echo e($gridColumns); ?> <?php echo e($gap); ?>">
            <?php echo e($slot); ?>

        </div>
        
        <div class="mt-4 flex justify-between">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
                Apply Filters
            </button>
            <a href="<?php echo e($action ?? url()->current()); ?>" class="text-gray-600 hover:text-gray-800">
                Clear Filters
            </a>
        </div>
    </form>
</div><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/components/filter-wrapper.blade.php ENDPATH**/ ?>