<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Member Demographics & Profile Reports')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">
            <!-- Age Distribution -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Age Distribution</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <canvas id="ageDistributionChart" height="250"></canvas>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Age Group</th>
                                        <th class="px-4 py-2 text-left">Count</th>
                                        <th class="px-4 py-2 text-left">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $totalMembers = array_sum($ageGroups) ?>
                                    <?php $__currentLoopData = $ageGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($group); ?></td>
                                        <td class="px-4 py-2"><?php echo e($count); ?></td>
                                        <td class="px-4 py-2">
                                            <?php echo e($totalMembers > 0 ? round(($count / $totalMembers) * 100, 1) : 0); ?>%
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gender Distribution -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Gender Distribution</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <canvas id="genderDistributionChart" height="250"></canvas>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Gender</th>
                                        <th class="px-4 py-2 text-left">Count</th>
                                        <th class="px-4 py-2 text-left">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $total = $genderDistribution->sum('count') ?>
                                    <?php $__currentLoopData = $genderDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gender): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($gender->sex ?? 'Not Specified'); ?></td>
                                        <td class="px-4 py-2"><?php echo e($gender->count); ?></td>
                                        <td class="px-4 py-2">
                                            <?php echo e($total > 0 ? round(($gender->count / $total) * 100, 1) : 0); ?>%
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Geographic Distribution -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Geographic Distribution</h3>
                    <?php $__currentLoopData = $geographicDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region => $provinces): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-6">
                        <h4 class="font-medium mb-2"><?php echo e($region); ?> (<?php echo e($provinces->sum('count')); ?> members)</h4>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Province</th>
                                        <th class="px-4 py-2 text-left">Count</th>
                                        <th class="px-4 py-2 text-left">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($province->province); ?></td>
                                        <td class="px-4 py-2"><?php echo e($province->count); ?></td>
                                        <td class="px-4 py-2">
                                            <?php echo e($provinces->sum('count') > 0 ? round(($province->count / $provinces->sum('count')) * 100, 1) : 0); ?>%
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Civil Status Breakdown -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Civil Status Breakdown</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <canvas id="civilStatusChart" height="250"></canvas>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Civil Status</th>
                                        <th class="px-4 py-2 text-left">Count</th>
                                        <th class="px-4 py-2 text-left">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $total = $civilStatus->sum('count') ?>
                                    <?php $__currentLoopData = $civilStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($status->civil_status); ?></td>
                                        <td class="px-4 py-2"><?php echo e($status->count); ?></td>
                                        <td class="px-4 py-2">
                                            <?php echo e($total > 0 ? round(($status->count / $total) * 100, 1) : 0); ?>%
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Section/Bureau Affiliation -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Section/Bureau Affiliation</h3>
                    <?php $__currentLoopData = $sectionAffiliation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bureau => $sections): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mb-6">
                        <h4 class="font-medium mb-2"><?php echo e($bureau); ?> (<?php echo e($sections->sum('members_count')); ?> members)</h4>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Section</th>
                                        <th class="px-4 py-2 text-left">Count</th>
                                        <th class="px-4 py-2 text-left">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($section->section_name); ?></td>
                                        <td class="px-4 py-2"><?php echo e($section->members_count); ?></td>
                                        <td class="px-4 py-2">
                                            <?php echo e($sections->sum('members_count') > 0 ? round(($section->members_count / $sections->sum('members_count')) * 100, 1) : 0); ?>%
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Emergency Contact Analysis -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Emergency Contact Relationships</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <canvas id="emergencyContactsChart" height="250"></canvas>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Relationship</th>
                                        <th class="px-4 py-2 text-left">Count</th>
                                        <th class="px-4 py-2 text-left">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $total = $emergencyContacts->sum('count') ?>
                                    <?php $__currentLoopData = $emergencyContacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($contact->relationship); ?></td>
                                        <td class="px-4 py-2"><?php echo e($contact->count); ?></td>
                                        <td class="px-4 py-2">
                                            <?php echo e($total > 0 ? round(($contact->count / $total) * 100, 1) : 0); ?>%
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Age Distribution Chart
        new Chart(document.getElementById('ageDistributionChart'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_keys($ageGroups), 15, 512) ?>,
                datasets: [{
                    label: 'Members',
                    data: <?php echo json_encode(array_values($ageGroups), 15, 512) ?>,
                    backgroundColor: 'rgba(79, 70, 229, 0.7)',
                    borderColor: 'rgba(79, 70, 229, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: { display: false },
                    title: { display: true, text: 'Age Distribution' }
                },
                scales: {
                    y: { beginAtZero: true }
                }
            }
        });

        // Gender Distribution Chart
        new Chart(document.getElementById('genderDistributionChart'), {
            type: 'pie',
            data: {
                labels: <?php echo json_encode($genderDistribution->pluck('sex'), 15, 512) ?>,
                datasets: [{
                    data: <?php echo json_encode($genderDistribution->pluck('count'), 15, 512) ?>,
                    backgroundColor: [
                        'rgba(99, 102, 241, 0.7)',
                        'rgba(244, 63, 94, 0.7)',
                        'rgba(20, 184, 166, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: { display: true, text: 'Gender Distribution' }
                }
            }
        });

        // Civil Status Chart
        new Chart(document.getElementById('civilStatusChart'), {
            type: 'doughnut',
            data: {
                labels: <?php echo json_encode($civilStatus->pluck('civil_status'), 15, 512) ?>,
                datasets: [{
                    data: <?php echo json_encode($civilStatus->pluck('count'), 15, 512) ?>,
                    backgroundColor: [
                        'rgba(79, 70, 229, 0.7)',
                        'rgba(219, 39, 119, 0.7)',
                        'rgba(20, 184, 166, 0.7)',
                        'rgba(234, 88, 12, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: { display: true, text: 'Civil Status Breakdown' }
                }
            }
        });

        // Emergency Contacts Chart
        new Chart(document.getElementById('emergencyContactsChart'), {
            type: 'polarArea',
            data: {
                labels: <?php echo json_encode($emergencyContacts->pluck('relationship'), 15, 512) ?>,
                datasets: [{
                    data: <?php echo json_encode($emergencyContacts->pluck('count'), 15, 512) ?>,
                    backgroundColor: [
                        'rgba(99, 102, 241, 0.7)',
                        'rgba(244, 63, 94, 0.7)',
                        'rgba(20, 184, 166, 0.7)',
                        'rgba(234, 88, 12, 0.7)',
                        'rgba(139, 92, 246, 0.7)',
                        'rgba(6, 182, 212, 0.7)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: { display: true, text: 'Emergency Contact Relationships' }
                }
            }
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/reports/member-demographics.blade.php ENDPATH**/ ?>