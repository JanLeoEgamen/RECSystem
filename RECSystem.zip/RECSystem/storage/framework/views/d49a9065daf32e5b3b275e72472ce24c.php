<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\REC-Capstone\RECSystem\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>