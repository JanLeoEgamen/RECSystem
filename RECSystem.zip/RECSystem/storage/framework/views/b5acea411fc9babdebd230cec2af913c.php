<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between">
            <h2 class="font-semibold text-4xl text-white dark:text-gray-200 leading-tight">
                <?php echo e(__('Renew Membership')); ?>

            </h2>
            <a href="<?php echo e(route('members.index')); ?>" class="inline-block px-5 py-2 text-white hover:text-[#101966] hover:border-[#101966] bg-[#101966] hover:bg-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#101966] border border-white border font-medium dark:border-[#3E3E3A] dark:hover:bg-black dark:hover:border-[#3F53E8] rounded-lg text-xl leading-normal">Back</a>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <?php if (isset($component)) { $__componentOriginal88b0e6813f5b80100a19437aa80e29ba = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal88b0e6813f5b80100a19437aa80e29ba = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal88b0e6813f5b80100a19437aa80e29ba)): ?>
<?php $attributes = $__attributesOriginal88b0e6813f5b80100a19437aa80e29ba; ?>
<?php unset($__attributesOriginal88b0e6813f5b80100a19437aa80e29ba); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b0e6813f5b80100a19437aa80e29ba)): ?>
<?php $component = $__componentOriginal88b0e6813f5b80100a19437aa80e29ba; ?>
<?php unset($__componentOriginal88b0e6813f5b80100a19437aa80e29ba); ?>
<?php endif; ?>
            
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <form action="<?php echo e(route('members.renew', $member->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        
                        <div class="grid grid-cols-1 gap-6">
                            <!-- Member Information -->
                            <div class="space-y-4">
                                <h3 class="text-lg font-medium">Member Information</h3>
                                <div>
                                    <p class="text-sm font-medium">Name:</p>
                                    <p class="mt-1"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium">Current Membership Type:</p>
                                    <p class="mt-1"><?php echo e($member->membershipType->type_name); ?></p>
                                </div>
                                <div>
                                    <p class="text-sm font-medium">Current Expiration:</p>
                                    <p class="mt-1">
                                        <?php if($member->is_lifetime_member): ?>
                                            Lifetime Membership
                                        <?php else: ?>
                                            <?php echo e($member->membership_end ? \Carbon\Carbon::parse($member->membership_end)->format('M d, Y') : 'Not set'); ?>

                                        <?php endif; ?>
                                    </p>
                                </div>
                            </div>
                            
                            <!-- Renewal Options -->
                            <div class="space-y-4">
                                <h3 class="text-lg font-medium">Renewal Options</h3>
                                
                                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                    <div>
                                        <label for="years" class="block text-sm font-medium">Years</label>
                                        <input type="number" name="years" id="years" 
                                               class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm" 
                                               min="0" value="0">
                                    </div>
                                    
                                    <div>
                                        <label for="months" class="block text-sm font-medium">Months</label>
                                        <input type="number" name="months" id="months" 
                                               class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm" 
                                               min="0" max="11" value="0">
                                    </div>
                                    
                                    <div>
                                        <label for="days" class="block text-sm font-medium">Days</label>
                                        <input type="number" name="days" id="days" 
                                               class="mt-1 block w-full rounded-lg border-gray-300 shadow-sm" 
                                               min="0" max="30" value="0">
                                    </div>
                                </div>
                                
                                <div class="mt-4">
                                    <label class="inline-flex items-center">
                                    <input type="checkbox" name="make_lifetime" id="make_lifetime" value="1" class="rounded">
                                        <span class="ml-2">Make this a lifetime membership</span>
                                    </label>
                                </div>
                                
                                <div class="mt-4 bg-blue-50 dark:bg-blue-900 p-4 rounded-lg">
                                    <p class="text-sm font-medium">New expiration date will be:</p>
                                    <p id="new_expiration_date" class="font-semibold mt-1">
                                        <?php echo e($member->is_lifetime_member ? 'Lifetime Membership' : 
                                           ($member->membership_end ? \Carbon\Carbon::parse($member->membership_end)->format('M d, Y') : 'Not calculated')); ?>

                                    </p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="mt-6 flex justify-end">
                            <button type="submit" class="flex items-center px-4 py-2 text-sm text-green-600 hover:text-white hover:bg-green-600 rounded-md transition-colors duration-200 border border-green-100 hover:border-green-600 font-medium">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                                </svg>
                                Process Renewal
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const yearsInput = document.getElementById('years');
            const monthsInput = document.getElementById('months');
            const daysInput = document.getElementById('days');
            const lifetimeCheckbox = document.getElementById('make_lifetime');
            const expirationDisplay = document.getElementById('new_expiration_date');
            
            // Current expiration date or today if none
            const currentExpiration = '<?php echo e($member->membership_end ? $member->membership_end : now()); ?>';
            let baseDate = currentExpiration ? new Date(currentExpiration) : new Date();
            
            // Function to calculate and display new expiration date
            function updateExpirationDate() {
                if (lifetimeCheckbox.checked) {
                    expirationDisplay.textContent = 'Lifetime Membership';
                    yearsInput.disabled = monthsInput.disabled = daysInput.disabled = true;
                    return;
                }
                
                yearsInput.disabled = monthsInput.disabled = daysInput.disabled = false;
                
                const years = parseInt(yearsInput.value) || 0;
                const months = parseInt(monthsInput.value) || 0;
                const days = parseInt(daysInput.value) || 0;
                
                if (years === 0 && months === 0 && days === 0) {
                    expirationDisplay.textContent = 'Please enter a duration';
                    return;
                }
                
                // Calculate new date
                const newDate = new Date(baseDate);
                newDate.setFullYear(newDate.getFullYear() + years);
                newDate.setMonth(newDate.getMonth() + months);
                newDate.setDate(newDate.getDate() + days);
                
                // Format the date for display
                const options = { year: 'numeric', month: 'short', day: 'numeric' };
                expirationDisplay.textContent = newDate.toLocaleDateString('en-US', options);
            }
            
            // Add event listeners
            [yearsInput, monthsInput, daysInput, lifetimeCheckbox].forEach(element => {
                element.addEventListener('change', updateExpirationDate);
                element.addEventListener('input', updateExpirationDate);
            });
            
            // Initialize
            updateExpirationDate();
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/members/renew.blade.php ENDPATH**/ ?>