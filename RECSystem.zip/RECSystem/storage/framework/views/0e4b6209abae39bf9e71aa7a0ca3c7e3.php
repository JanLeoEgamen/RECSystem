<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Growth, Trends & Projections')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">
            <!-- Membership Growth by Type -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Membership Growth by Type</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <?php $__currentLoopData = $growthByType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div>
                            <h4 class="font-medium mb-2"><?php echo e($type->type_name); ?></h4>
                            <canvas id="growthChart<?php echo e($type->id); ?>" height="200"></canvas>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <!-- New Members Over Time -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">New Members Over Time</h3>
                    <div class="mb-6">
                        <ul class="flex flex-wrap -mb-px">
                            <li class="mr-2">
                                <button onclick="showTab('monthly')" class="inline-block p-4 border-b-2 border-blue-600 rounded-t-lg active" id="monthly-tab">Monthly</button>
                            </li>
                            <li class="mr-2">
                                <button onclick="showTab('quarterly')" class="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300" id="quarterly-tab">Quarterly</button>
                            </li>
                            <li class="mr-2">
                                <button onclick="showTab('yearly')" class="inline-block p-4 border-b-2 border-transparent rounded-t-lg hover:text-gray-600 hover:border-gray-300" id="yearly-tab">Yearly</button>
                            </li>
                        </ul>
                    </div>

                    <div id="monthly-content" class="tab-content">
                        <canvas id="monthlyMembersChart" height="200"></canvas>
                    </div>

                    <div id="quarterly-content" class="tab-content hidden">
                        <canvas id="quarterlyMembersChart" height="200"></canvas>
                    </div>

                    <div id="yearly-content" class="tab-content hidden">
                        <canvas id="yearlyMembersChart" height="200"></canvas>
                    </div>
                </div>
            </div>

            <!-- Section Performance -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Section Performance</h3>
                    <div class="overflow-x-auto">
                        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead class="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-2 text-left">Section</th>
                                    <th class="px-4 py-2 text-left">Bureau</th>
                                    <th class="px-4 py-2 text-left">Total Members</th>
                                    <th class="px-4 py-2 text-left">Growth Trend</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <?php $__currentLoopData = $sectionPerformance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-2"><?php echo e($section->name); ?></td>
                                    <td class="px-4 py-2"><?php echo e($section->bureau->name ?? 'N/A'); ?></td>
                                    <td class="px-4 py-2"><?php echo e($section->members_count); ?></td>
                                    <td class="px-4 py-2">
                                        <?php if($section->members->count() > 1): ?>
                                            <?php
                                                $firstYear = $section->members->first()->count;
                                                $lastYear = $section->members->last()->count;
                                                $growth = $firstYear > 0 ? (($lastYear - $firstYear) / $firstYear) * 100 : 0;
                                            ?>
                                            <span class="<?php echo e($growth >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400'); ?>">
                                                <?php echo e(round($growth, 1)); ?>%
                                            </span>
                                        <?php else: ?>
                                            N/A
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Membership Type Distribution -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Membership Type Distribution</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <canvas id="typeDistributionChart" height="200"></canvas>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Membership Type</th>
                                        <th class="px-4 py-2 text-left">Members</th>
                                        <th class="px-4 py-2 text-left">Percentage</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $totalMembers = $membershipTypeDistribution->sum('members_count'); ?>
                                    <?php $__currentLoopData = $membershipTypeDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($type->type_name); ?></td>
                                        <td class="px-4 py-2"><?php echo e($type->members_count); ?></td>
                                        <td class="px-4 py-2"><?php echo e($totalMembers > 0 ? round(($type->members_count / $totalMembers) * 100, 1) : 0); ?>%</td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="font-bold">
                                        <td class="px-4 py-2">Total</td>
                                        <td class="px-4 py-2"><?php echo e($totalMembers); ?></td>
                                        <td class="px-4 py-2">100%</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Membership Duration Analysis -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Membership Duration Analysis</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <div>
                            <canvas id="durationChart" height="200"></canvas>
                        </div>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                                <thead class="bg-gray-50 dark:bg-gray-700">
                                    <tr>
                                        <th class="px-4 py-2 text-left">Membership Type</th>
                                        <th class="px-4 py-2 text-left">Avg. Duration (Years)</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                    <?php $__currentLoopData = $membershipDuration; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="px-4 py-2"><?php echo e($type->type_name); ?></td>
                                        <td class="px-4 py-2"><?php echo e(round($type->avg_duration, 1)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Membership Growth by Type Charts
    <?php $__currentLoopData = $growthByType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    new Chart(document.getElementById('growthChart<?php echo e($type->id); ?>'), {
        type: 'line',
        data: {
            labels: <?php echo json_encode($type->members->groupBy('year')->keys()); ?>,
            datasets: [{
                label: '<?php echo e($type->type_name); ?> Growth',
                data: <?php echo json_encode($type->members->groupBy('year')->map(function($items) {
                    return $items->sum('count');
                })); ?>,
                borderColor: `rgba(${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, 1)`,
                backgroundColor: `rgba(${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, 0.1)`,
                fill: true,
                tension: 0.3
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: '<?php echo e($type->type_name); ?> Growth' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    // New Members Over Time Charts
    // Monthly
    new Chart(document.getElementById('monthlyMembersChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode(collect($newMembersMonthly->first())->map(function($item) {
                return new Date(item.year, item.month - 1).toLocaleString('default', { month: 'short' }) + ' ' + item.year;
            }); ?>,
            datasets: [
                <?php $__currentLoopData = $newMembersMonthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    label: '<?php echo e($year); ?>',
                    data: <?php echo json_encode($months->pluck('count')); ?>,
                    backgroundColor: `rgba(${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, 0.7)`,
                    borderWidth: 1
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Monthly New Members' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Quarterly
    new Chart(document.getElementById('quarterlyMembersChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($newMembersQuarterly->first()->map(function($item) {
                return 'Q' + item.quarter + ' ' + item.year;
            })); ?>,
            datasets: [
                <?php $__currentLoopData = $newMembersQuarterly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year => $quarters): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                {
                    label: '<?php echo e($year); ?>',
                    data: <?php echo json_encode($quarters->pluck('count')); ?>,
                    backgroundColor: `rgba(${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, 0.7)`,
                    borderWidth: 1
                },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Quarterly New Members' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Yearly
    new Chart(document.getElementById('yearlyMembersChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($newMembersYearly->pluck('year')); ?>,
            datasets: [{
                label: 'New Members',
                data: <?php echo json_encode($newMembersYearly->pluck('count')); ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.7)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Yearly New Members' }
            },
            scales: {
                y: { beginAtZero: true }
            }
        }
    });

    // Type Distribution Chart
    new Chart(document.getElementById('typeDistributionChart'), {
        type: 'pie',
        data: {
            labels: <?php echo json_encode($membershipTypeDistribution->pluck('type_name')); ?>,
            datasets: [{
                data: <?php echo json_encode($membershipTypeDistribution->pluck('members_count')); ?>,
                backgroundColor: [
                    <?php $__currentLoopData = $membershipTypeDistribution; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    `rgba(${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, ${Math.floor(Math.random() * 150) + 50}, 0.7)`,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Membership Type Distribution' }
            }
        }
    });

    // Duration Analysis Chart
    new Chart(document.getElementById('durationChart'), {
        type: 'bar',
        data: {
            labels: <?php echo json_encode($membershipDuration->pluck('type_name')); ?>,
            datasets: [{
                label: 'Average Duration (Years)',
                data: <?php echo json_encode($membershipDuration->pluck('avg_duration')); ?>,
                backgroundColor: 'rgba(75, 192, 192, 0.7)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: { display: true, text: 'Average Membership Duration by Type' }
            },
            scales: {
                y: { 
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value + ' yrs';
                        }
                    }
                }
            }
        }
    });

    // Tab switching function
    function showTab(tabName) {
        // Hide all tab content
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.add('hidden');
        });

        // Remove active class from all tabs
        document.querySelectorAll('[id$="-tab"]').forEach(tab => {
            tab.classList.remove('border-blue-600', 'active');
            tab.classList.add('border-transparent');
        });

        // Show selected tab content
        document.getElementById(tabName + '-content').classList.remove('hidden');

        // Add active class to selected tab
        document.getElementById(tabName + '-tab').classList.add('border-blue-600', 'active');
        document.getElementById(tabName + '-tab').classList.remove('border-transparent');
    }
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/reports/growth-trends.blade.php ENDPATH**/ ?>