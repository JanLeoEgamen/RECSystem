<div class="grid grid-cols-1 md:grid-cols-3 gap-4">
    <div>
        <label for="status" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Status</label>
        <select id="status" name="filters[status]" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            <option value="">All Statuses</option>
            <option value="pending">Pending</option>
            <option value="approved">Approved</option>
            <option value="rejected">Rejected</option>
        </select>
    </div>
    
    <div>
        <label for="converted" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Conversion Status</label>
        <select id="converted" name="filters[converted]" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
            <option value="">All</option>
            <option value="1">Converted to Member</option>
            <option value="0">Not Converted</option>
        </select>
    </div>
    
    <div>
        <label for="date_range" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Date Range</label>
        <input type="text" id="date_range" name="filters[date_range]" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Select date range">
    </div>
</div><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/reports/partials/_applicants_filters.blade.php ENDPATH**/ ?>