<?php echo e($slot); ?>

<?php /**PATH C:\REC-Capstone\RECSystem\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>