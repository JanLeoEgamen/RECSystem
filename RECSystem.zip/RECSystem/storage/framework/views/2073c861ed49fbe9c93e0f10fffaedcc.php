<div class="mb-6 bg-white p-4 rounded-lg shadow">
    <form method="GET" action="<?php echo e(url()->current()); ?>" id="filterForm">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <?php $__currentLoopData = $filterFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $options): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-1" for="filter_<?php echo e($field); ?>">
                        <?php echo e(ucfirst(str_replace('_', ' ', $field))); ?>

                    </label>
                    <?php if($options['type'] === 'select'): ?>
                        <select name="filters[<?php echo e($field); ?>]" id="filter_<?php echo e($field); ?>" 
                                class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                            <option value="">All</option>
                            <?php $__currentLoopData = $options['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value); ?>" <?php echo e(request('filters.'.$field) == $value ? 'selected' : ''); ?>>
                                    <?php echo e($label); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    <?php elseif($options['type'] === 'text'): ?>
                        <input type="text" name="filters[<?php echo e($field); ?>]" id="filter_<?php echo e($field); ?>" 
                               value="<?php echo e(request('filters.'.$field)); ?>"
                               class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                    <?php elseif($options['type'] === 'date'): ?>
                        <input type="date" name="filters[<?php echo e($field); ?>]" id="filter_<?php echo e($field); ?>" 
                               value="<?php echo e(request('filters.'.$field)); ?>"
                               class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                    <?php elseif($options['type'] === 'boolean'): ?>
                        <select name="filters[<?php echo e($field); ?>]" id="filter_<?php echo e($field); ?>" 
                                class="w-full border-gray-300 rounded-md shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50">
                            <option value="">All</option>
                            <option value="1" <?php echo e(request('filters.'.$field) === '1' ? 'selected' : ''); ?>>Yes</option>
                            <option value="0" <?php echo e(request('filters.'.$field) === '0' ? 'selected' : ''); ?>>No</option>
                        </select>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
        <div class="mt-4 flex justify-between">
            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">
                Apply Filters
            </button>
            <a href="<?php echo e(url()->current()); ?>" class="text-gray-600 hover:text-gray-800">
                Clear Filters
            </a>
        </div>
    </form>
</div><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/components/filter.blade.php ENDPATH**/ ?>