<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
    <div class="flex justify-between"> 
            <h2 class="font-semibold text-4xl text-white dark:text-gray-200 leading-tight">
                Users / Edit
            </h2>
                    <a href="<?php echo e(route('users.index')); ?>" class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-md flex items-center">
                        <svg class="h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18"/>
                        </svg>
                        Back to Users
                    </a>                
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <form action="<?php echo e(route('users.update', $user->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div>
                            <label for="first_name" class="text-sm font-medium">First Name</label>
                            <div class="my-3">    
                                <input value="<?php echo e(old('first_name', $user->first_name)); ?>" name="first_name" placeholder="Enter first name" type="text" class="border-gray-300 shadow-sm w-1/2 rounded-lg">
                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-400 font-medium"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <label for="last_name" class="text-sm font-medium">Last Name</label>
                            <div class="my-3">    
                                <input value="<?php echo e(old('last_name', $user->last_name)); ?>" name="last_name" placeholder="Enter last name" type="text" class="border-gray-300 shadow-sm w-1/2 rounded-lg">
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-400 font-medium"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <label for="birthdate" class="text-sm font-medium">Birthdate</label>
                            <div class="my-3">    
                                <input value="<?php echo e(old('birthdate', $user->birthdate ? (\Carbon\Carbon::parse($user->birthdate)->format('Y-m-d')) : '')); ?>" name="birthdate" type="date" class="border-gray-300 shadow-sm w-1/2 rounded-lg">
                                <?php $__errorArgs = ['birthdate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-400 font-medium"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <label for="" class="text-sm font-medium"> Email</label>
                            <div class = "my-3">    
                                <input value="<?php echo e(old('email', $user->email)); ?>" name="email" placeholder="Enter Email" type="text" class="border-gray-300 shadow-sm w-1/2 rounded-lg">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-red-400 font-medium"> <?php echo e($message); ?> </p>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mt-6">
                                <label class="text-sm font-medium">Assign Roles</label>

                                <div class="grid grid-cols-4 mb-3">
                                    <?php if($roles->isNotEmpty()): ?>
                                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="mt-3">
                                                <input <?php echo e($hasRoles->contains($role->id) ? 'checked' : ''); ?> type="checkbox" id="role-<?php echo e($role->id); ?>" class="rounded" name="role[]" value="<?php echo e($role->name); ?>">
                                                <label for="role-<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="mt-6">
                                <label class="text-sm font-medium">Assign to Bureaus</label>
                                <div class="grid grid-cols-4 gap-4 mt-2">
                                    <?php $__currentLoopData = $bureaus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bureau): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <input type="checkbox" id="bureau-<?php echo e($bureau->id); ?>" name="bureaus[]" value="<?php echo e($bureau->id); ?>" 
                                                <?php echo e($user->assignedBureaus->contains($bureau->id) ? 'checked' : ''); ?> class="rounded">
                                            <label for="bureau-<?php echo e($bureau->id); ?>"><?php echo e($bureau->bureau_name); ?></label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>

                            <div class="mt-6">
                                <label class="text-sm font-medium">Or Assign to Specific Sections</label>
                                <div class="grid grid-cols-4 gap-4 mt-2">
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <input type="checkbox" id="section-<?php echo e($section->id); ?>" name="sections[]" value="<?php echo e($section->id); ?>"
                                                <?php echo e($user->assignedSections->contains($section->id) ? 'checked' : ''); ?> class="rounded">
                                            <label for="section-<?php echo e($section->id); ?>">
                                                <?php echo e($section->section_name); ?> (<?php echo e($section->bureau->bureau_name); ?>)
                                            </label>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <button class="inline-block px-5 py-2 text-white hover:text-[#101966] hover:border-[#101966] bg-[#101966] hover:bg-white focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#101966] border border-white border font-medium dark:border-[#3E3E3A] dark:hover:bg-black dark:hover:border-[#3F53E8] rounded-lg text-xl leading-normal">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/users/edit.blade.php ENDPATH**/ ?>