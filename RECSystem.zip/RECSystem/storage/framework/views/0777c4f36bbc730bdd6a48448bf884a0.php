<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Membership Status & Validity Reports')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-8">
            <!-- Active/Inactive Members Card -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Active/Inactive Members</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                        <div class="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Active Members</p>
                            <p class="text-2xl font-bold"><?php echo e($activeCount); ?></p>
                        </div>
                        <div class="bg-red-100 dark:bg-red-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Inactive Members</p>
                            <p class="text-2xl font-bold"><?php echo e($inactiveCount); ?></p>
                        </div>
                    </div>
                    <canvas id="statusChart" height="100"></canvas>
                </div>
            </div>

            <!-- Lifetime vs Regular Members Card -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Lifetime vs Regular Members</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                        <div class="bg-purple-100 dark:bg-purple-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Lifetime Members</p>
                            <p class="text-2xl font-bold"><?php echo e($lifetimeCount); ?></p>
                        </div>
                        <div class="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Regular Members</p>
                            <p class="text-2xl font-bold"><?php echo e($regularCount); ?></p>
                        </div>
                    </div>
                    <canvas id="membershipTypeChart" height="100"></canvas>
                </div>
            </div>

            <!-- Membership Validity Table -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Membership Validity</h3>
                    <div class="overflow-x-auto">
                        <table id="membersValidityTable" class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead class="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-3 text-left">Name</th>
                                    <th class="px-4 py-3 text-left">Type</th>
                                    <th class="px-4 py-3 text-left">Status</th>
                                    <th class="px-4 py-3 text-left">Validity</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <!-- Data will be loaded via AJAX -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Renewal Report -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Memberships Expiring Soon</h3>
                    <?php $__currentLoopData = ['30 Days', '60 Days', '90 Days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($expiringSoon[$period])): ?>
                        <div class="mb-6">
                            <h4 class="font-medium mb-2">Expiring in <?php echo e($period); ?> (<?php echo e($expiringSoon[$period]->count()); ?>)</h4>
                            <div class="overflow-x-auto">
                                <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 datatable">
                                    <thead class="bg-gray-50 dark:bg-gray-700">
                                        <tr>
                                            <th class="px-4 py-2 text-left">Name</th>
                                            <th class="px-4 py-2 text-left">Expires On</th>
                                            <th class="px-4 py-2 text-left">Days Left</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                        <?php $__currentLoopData = $expiringSoon[$period]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="px-4 py-2"><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></td>
                                            <td class="px-4 py-2"><?php echo e(\Carbon\Carbon::parse($member->membership_end)->format('M d, Y')); ?></td>
                                            <td class="px-4 py-2"><?php echo e(now()->diffInDays($member->membership_end)); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Membership Type Distribution -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Membership Type Distribution</h3>
                    <canvas id="typeDistributionChart" height="100"></canvas>
                    <div class="mt-4 overflow-x-auto">
                        <table id="typeDistributionTable" class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead class="bg-gray-50 dark:bg-gray-700">
                                <tr>
                                    <th class="px-4 py-2 text-left">Type</th>
                                    <th class="px-4 py-2 text-left">Count</th>
                                    <th class="px-4 py-2 text-left">Percentage</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
                                <?php $__currentLoopData = $membershipTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-4 py-2"><?php echo e($type->name); ?></td>
                                    <td class="px-4 py-2"><?php echo e($type->members_count); ?></td>
                                    <td class="px-4 py-2">
                                        <?php echo e($totalMembers > 0 ? round(($type->members_count / $totalMembers) * 100, 2) : 0); ?>%
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Renewal Patterns -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Renewal Patterns</h3>
                    <canvas id="renewalPatternsChart" height="100"></canvas>
                </div>
            </div>

            <!-- Retention Rates -->
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                    <h3 class="text-lg font-semibold mb-4">Member Retention Rates</h3>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div class="bg-indigo-100 dark:bg-indigo-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Total Members</p>
                            <p class="text-2xl font-bold"><?php echo e($totalMembers); ?></p>
                        </div>
                        <div class="bg-green-100 dark:bg-green-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Renewed Members</p>
                            <p class="text-2xl font-bold"><?php echo e($renewedMembers); ?></p>
                        </div>
                        <div class="bg-blue-100 dark:bg-blue-900 p-4 rounded-lg">
                            <p class="text-sm font-medium">Retention Rate</p>
                            <p class="text-2xl font-bold"><?php echo e(round($retentionRate, 2)); ?>%</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>
    <script>
        $(document).ready(function() {
            // Initialize DataTable for Membership Validity
            $('#membersValidityTable').DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('members.validity.data')); ?>",
                columns: [
                    { data: 'name', name: 'name' },
                    { data: 'type', name: 'membershipType.name' },
                    { data: 'status_badge', name: 'status' },
                    { data: 'days_remaining', name: 'membership_end' }
                ],
                responsive: true,
                order: [[3, 'asc']] // Sort by validity by default
            });

            // Initialize simple DataTables for other tables
            $('.datatable').DataTable({
                responsive: true,
                paging: false,
                searching: false,
                info: false
            });

            // Active/Inactive Chart
            new Chart(document.getElementById('statusChart'), {
                type: 'doughnut',
                data: {
                    labels: ['Active', 'Inactive'],
                    datasets: [{
                        data: [<?php echo e($activeCount); ?>, <?php echo e($inactiveCount); ?>],
                        backgroundColor: ['#4ade80', '#f87171'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'right' },
                        title: { display: true, text: 'Active/Inactive Members' }
                    }
                }
            });

            // Lifetime vs Regular Chart
            new Chart(document.getElementById('membershipTypeChart'), {
                type: 'pie',
                data: {
                    labels: ['Lifetime', 'Regular'],
                    datasets: [{
                        data: [<?php echo e($lifetimeCount); ?>, <?php echo e($regularCount); ?>],
                        backgroundColor: ['#a78bfa', '#60a5fa'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'right' },
                        title: { display: true, text: 'Lifetime vs Regular Members' }
                    }
                }
            });

            // Type Distribution Chart
            new Chart(document.getElementById('typeDistributionChart'), {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($membershipTypes->pluck('name'), 15, 512) ?>,
                    datasets: [{
                        label: 'Members',
                        data: <?php echo json_encode($membershipTypes->pluck('members_count'), 15, 512) ?>,
                        backgroundColor: '#6366f1',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    scales: { y: { beginAtZero: true } },
                    plugins: {
                        legend: { display: false },
                        title: { display: true, text: 'Membership Type Distribution' }
                    }
                }
            });

            // Renewal Patterns Chart
            new Chart(document.getElementById('renewalPatternsChart'), {
                type: 'line',
                data: {
                    labels: <?php echo json_encode($renewalPatterns->keys(), 15, 512) ?>,
                    datasets: [{
                        label: 'Renewals',
                        data: <?php echo json_encode($renewalPatterns->values(), 15, 512) ?>,
                        borderColor: '#f59e0b',
                        backgroundColor: 'rgba(245, 158, 11, 0.1)',
                        fill: true,
                        tension: 0.3
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: { display: true, text: 'Monthly Renewal Patterns' }
                    },
                    scales: {
                        y: { beginAtZero: true }
                    }
                }
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\REC-Capstone\RECSystem\resources\views/reports/membership-status-validity.blade.php ENDPATH**/ ?>