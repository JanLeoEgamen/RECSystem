<?php echo e($slot); ?>

<?php /**PATH C:\REC-Capstone\RECSystem\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>